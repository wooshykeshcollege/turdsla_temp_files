poses = [];
for i=0:height(table)
    disp(table.ActorPoses);
end