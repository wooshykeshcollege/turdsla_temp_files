function [varargout]= vdynblksrefconfig(varargin)
%

%   Copyright 2018-2022 The MathWorks, Inc.

% Disable OpenGL warning for parsim

warning('off','MATLAB:Figure:UnableToSetRendererToOpenGL');

block = varargin{1};
maskMode = varargin{2};
varargout{1} = {};
simStopped = autoblkschecksimstopped(block) && ~(strcmp(get_param(bdroot(block),'SimulationStatus'),'updating'));
manType = get_param(block,'manType');
prevType = get_param(block,'prevType');
vehSys = bdroot(block);
manOverride = strcmp(get_param(block,'manOverride'),'on');
sim3dEnabled = strcmp(get_param(block,'engine3D'),'Enabled');

switch maskMode
    case 0
        [~]=vdynblksrefconfig(block,1);
        [~]=vdynblksrefconfig(block,3);
    case 1
        switch manType
            case 'Double Lane Change'
                set_param([block '/Reference Generator'],'LabelModeActiveChoice','Double Lane Change');
                set_param([vehSys '/Visualization/Scope Type'],'LabelModeActiveChoice','1');
                set_param([vehSys '/Visualization/Vehicle XY Plotter'],'LabelModeActiveChoice','1');
                if manOverride  && ~strcmp(prevType,manType)
                    set_param([vehSys '/Vehicle/Plant Models/Causal Models/Body, Suspension, Wheels'],'LabelModeActiveChoice','Lateral Vehicle Dynamics');
                end
                autoblksenableparameters(block, [], [],{'DLCGroup'},{'ISGroup';'CRGroup';'SSGroup';'SDGroup';'FHGroup';'DCGroup'});
                autoblksenableparameters(block,{'t_start','xdot_r'},{'steerDir'},[],[],true);
                if simStopped && manOverride  && ~strcmp(prevType,manType)
                    set_param([vehSys '/Driver Commands'],'driverType','Predictive Driver');
                end
                simTime = 25;
            case 'Increasing Steer'
                set_param([block '/Reference Generator'],'LabelModeActiveChoice','Increasing Steer');
                set_param([vehSys '/Visualization/Scope Type'],'LabelModeActiveChoice','0');
                set_param([vehSys '/Visualization/Vehicle XY Plotter'],'LabelModeActiveChoice','0');
                if manOverride  && ~strcmp(prevType,manType)
                    set_param([vehSys '/Vehicle/Plant Models/Causal Models/Body, Suspension, Wheels'],'LabelModeActiveChoice','Lateral Vehicle Dynamics');
                end
                autoblksenableparameters(block, [], [],{'ISGroup'},{'DLCGroup';'CRGroup';'SSGroup';'SDGroup';'FHGroup';'DCGroup'});
                autoblksenableparameters(block,{'steerDir','t_start','xdot_r'},[],[],[],true);
                if simStopped && manOverride && ~strcmp(prevType,manType)
                    set_param([vehSys '/Driver Commands'],'driverType','Longitudinal Driver');
                end
                simTime = 60;
            case 'Swept Sine'
                set_param([block '/Reference Generator'],'LabelModeActiveChoice','Swept Sine');
                set_param([vehSys '/Visualization/Scope Type'],'LabelModeActiveChoice','0');
                set_param([vehSys '/Visualization/Vehicle XY Plotter'],'LabelModeActiveChoice','0');
                if manOverride  && ~strcmp(prevType,manType)
                    set_param([vehSys '/Vehicle/Plant Models/Causal Models/Body, Suspension, Wheels'],'LabelModeActiveChoice','Lateral Vehicle Dynamics');
                end
                autoblksenableparameters(block, [], [],{'SSGroup'},{'ISGroup';'DLCGroup';'CRGroup';'SDGroup';'FHGroup';'DCGroup'});
                autoblksenableparameters(block,[],{'steerDir','t_start','xdot_r'},[],[],true);
                if simStopped && manOverride  && ~strcmp(prevType,manType)
                    set_param([vehSys '/Driver Commands'],'driverType','Longitudinal Driver');
                end
                simTime = 40;
            case 'Sine with Dwell'
                set_param([block '/Reference Generator'],'LabelModeActiveChoice','Sine with Dwell');
                set_param([vehSys '/Visualization/Scope Type'],'LabelModeActiveChoice','0');
                set_param([vehSys '/Visualization/Vehicle XY Plotter'],'LabelModeActiveChoice','0');
                if manOverride  && ~strcmp(prevType,manType)
                    set_param([vehSys '/Vehicle/Plant Models/Causal Models/Body, Suspension, Wheels'],'LabelModeActiveChoice','Lateral Vehicle Dynamics');
                end
                autoblksenableparameters(block, [], [],{'SDGroup'},{'ISGroup';'DLCGroup';'CRGroup';'SSGroup';'FHGroup';'DCGroup'});
                autoblksenableparameters(block,{'steerDir','t_start','xdot_r'},[],[],[],true);
                if simStopped && manOverride  && ~strcmp(prevType,manType)
                    set_param([vehSys '/Driver Commands'],'driverType','Longitudinal Driver');
                end
                simTime = 25;
            case 'Constant Radius'
                set_param([block '/Reference Generator'],'LabelModeActiveChoice','Constant Radius');
                set_param([vehSys '/Visualization/Scope Type'],'LabelModeActiveChoice','2');
                set_param([vehSys '/Visualization/Vehicle XY Plotter'],'LabelModeActiveChoice','1');
                if manOverride  && ~strcmp(prevType,manType)
                    set_param([vehSys '/Vehicle/Plant Models/Causal Models/Body, Suspension, Wheels'],'LabelModeActiveChoice','Lateral Vehicle Dynamics');
                end
                autoblksenableparameters(block, [], [],{'CRGroup'},{'DLCGroup';'ISGroup';'SSGroup';'SDGroup';'FHGroup';'DCGroup'});
                autoblksenableparameters(block,{'steerDir','t_start','xdot_r'},[],[],[],true);
                if simStopped && manOverride  && ~strcmp(prevType,manType)
                    set_param([vehSys '/Driver Commands'],'driverType','Predictive Driver');  % this in turn will also update the driver params if needed
                end
                simTime = 60;
            case 'Fishhook'
                set_param([block '/Reference Generator'],'LabelModeActiveChoice','Fishhook');
                set_param([vehSys '/Visualization/Scope Type'],'LabelModeActiveChoice','0');
                set_param([vehSys '/Visualization/Vehicle XY Plotter'],'LabelModeActiveChoice','0');
                if manOverride  && ~strcmp(prevType,manType)
                    set_param([vehSys '/Vehicle/Plant Models/Causal Models/Body, Suspension, Wheels'],'LabelModeActiveChoice','Lateral Vehicle Dynamics');
                end
                autoblksenableparameters(block, [], [],{'FHGroup'},{'ISGroup';'DLCGroup';'CRGroup';'SDGroup';'SSGroup';'DCGroup'});
                autoblksenableparameters(block,{'steerDir','t_start','xdot_r'},[],[],[],true);
                pFdbkChk = get_param(block,'pFdbk');
                if strcmp(pFdbkChk,'off')
                    autoblksenableparameters(block,{'tDwell1'},{'pZero'},[],[],'false')
                else
                    autoblksenableparameters(block,{'pZero'},{'tDwell1'},[],[],'false')
                end
                if simStopped && manOverride && ~strcmp(prevType,manType)
                    set_param([vehSys '/Driver Commands'],'driverType','Longitudinal Driver');
                end
                simTime = 40;
            case 'Drive Cycle'
                set_param([block '/Reference Generator'],'LabelModeActiveChoice','Drive Cycle');
                set_param([vehSys '/Visualization/Scope Type'],'LabelModeActiveChoice','0');
                set_param([vehSys '/Visualization/Vehicle XY Plotter'],'LabelModeActiveChoice','2');
                autoblksenableparameters(block, [], [],{'DCGroup'},{'ISGroup';'CRGroup';'SSGroup';'SDGroup';'FHGroup';'DLCGroup'});
                autoblksenableparameters(block,[],{'steerDir','t_start','xdot_r'},[],[],true);
                if simStopped && manOverride && ~strcmp(prevType,manType)
                    set_param([vehSys '/Vehicle/Plant Models/Causal Models/Body, Suspension, Wheels'],'LabelModeActiveChoice','Longitudinal Vehicle Dynamics');
                    set_param([vehSys '/Driver Commands'],'driverType','Longitudinal Driver');
                    set_param(block,'engine3D','Disabled');
                end
                loadedCycle = get_param([block '/Reference Generator/Drive Cycle/Drive Cycle Source'],'UserData');
                timeVec = loadedCycle.Time;
                simTime = timeVec(end);
            otherwise
        end
        % update driver sldd, and 3D initial positions
        if simStopped && manOverride && ~strcmp(prevType,manType)
            update3DScene(block,manType);
            [~] = vdynblksmdlWSconfig(block,false);
            dictionaryObj = Simulink.data.dictionary.open('VirtualVehicleTemplate.sldd');
            dDataSectObj = getSection(dictionaryObj,'Design Data');
            list=VirtualAssemblyScenarioParaList(manType);
            for i=1:length(list)
                ddObj = getEntry(dDataSectObj,list{i}{1});
                setValue(ddObj,str2double(list{i}{2}));
            end

            saveChanges(dictionaryObj);
        end

        if simStopped && manOverride
            try
                configset.reference.overrideParameter(vehSys,'StopTime',num2str(simTime));
            catch
                set_param(vehSys,'StopTime',num2str(simTime));
            end
            set_param(block,'simTime',num2str(simTime));

        end

        set_param(block,'prevType',manType)
    case 2  % update time button
        simTime = get_param(block,'simTime');

        try
            configset.reference.overrideParameter(vehSys,'StopTime',simTime);
        catch
            set_param(vehSys,'StopTime',num2str(simTime));
        end

    case 3 % manual override button
        if manOverride
            autoblksenableparameters(block,[],[],[],{'simTimeGroup'},true);
        else
            autoblksenableparameters(block,[],[],{'simTimeGroup'},[],true);
        end
    case 4 % mask update for graphics enabling
        if sim3dEnabled
            autoblksenableparameters(block,[],[],{'engine3DSettingsGroup'},[],true);
        else
            autoblksenableparameters(block,[],[],[],{'engine3DSettingsGroup'},true);
        end

end
end
function update3DScene(block,manType)
sim3DBlkPath = block;
if strcmp(manType,'Double Lane Change')
    set_param(sim3DBlkPath,'SceneDesc','Double lane change');
else
    set_param(sim3DBlkPath,'SceneDesc','Open surface');
end
end