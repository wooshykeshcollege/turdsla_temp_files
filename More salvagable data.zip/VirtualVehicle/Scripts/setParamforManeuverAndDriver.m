function out = setParamforManeuverAndDriver(Maneuver, ManeuverOption, Driver, TestID, in)
%

%   Copyright 2021-2022 The MathWorks, Inc.

% Setup Mask Parameters
ManeuverType = 'manType';
ManeuverMaskPath = 'ConfiguredVirtualVehicleModel/Reference Generator';
DriverTypePath = 'ConfiguredVirtualVehicleModel/Driver Commands';
DriverType = 'driverType';

in=in.setBlockParameter(ManeuverMaskPath,'manOverride','off');
if strcmp(Maneuver,'Drive Cycle')
    in=in.setBlockParameter(ManeuverMaskPath,'manOverride','off',...
        DriverTypePath,DriverType,Driver, ...
        ManeuverMaskPath,ManeuverType,Maneuver, ...
        ManeuverMaskPath,'cycleVar',ManeuverOption);

    cyclename=['cycle',ManeuverOption];
    cycle=load(cyclename);
    simTime=cycle.(cyclename).Time(end);
    
else
    in=in.setBlockParameter(ManeuverMaskPath,'manOverride','off',...
        DriverTypePath,DriverType,Driver, ...
        ManeuverMaskPath,ManeuverType,Maneuver, ...
        ManeuverMaskPath,'engine3D',ManeuverOption);

    switch Maneuver
        case 'Double Lane Change'
            simTime = 25;          
            in=in.setBlockParameter(ManeuverMaskPath,'SceneDesc','Double lane change');
        case 'Increasing Steer'
            simTime = 60;
        case 'Swept Sine'
            simTime = 40;
        case 'Sine with Dwell'
            simTime = 25;
        case 'Constant Radius'
            simTime = 60;
        case 'Fishhook'
            simTime = 40;
    end
end

in=in.setModelParameter('StopTime',num2str(simTime));

% Update simulation test data parameters

map={'ScnSteerDir','steerDir';...
 'ScnLongVelUnit','xdotUnit';...
 'ScnISLatAccStop','ay_stop';...  
};

Config = load('ConfigInfo.mat');
testdata=Config.ConfigInfos.TestPlanArray{str2double(TestID)}.Data;
if ~isempty(testdata)
    for i = 1 : length(testdata)
        var=testdata{i};

        index=find(strcmp(var{1},map(:,1)),1);

        if ~isempty(index)
            in=in.setBlockParameter(ManeuverMaskPath,map{index,2},var{2});
        elseif strcmp(var{1},'ScnSimTime')
            in=in.setModelParameter('StopTime',num2str(var{2}));
        else
            newvalue=str2double(var{2});
            if isnan(newvalue)
                in=in.setVariable(var{1},var{2});
            else
                in=in.setVariable(var{1},newvalue);
            end
        end
    end
end

out = in;

end
