%% Create system data for standard feedback configuration
% Define F
F = tunableGain('F',ones([1,1]));
F.InputName = 'rSwitchOutputName';     F.OutputName = 'rf';      F.Name = 'F';
% Define C
C = tunableGain('C',ones([1,1]));
C.InputName = 'e';     C.OutputName = 'uc';      C.Name = 'C';
% Define G
G = ss(ones([1,1]));
G.InputName = 'u';     G.OutputName = 'yg';      G.Name = 'G';
% Define H
H = ss(ones([1,1]));
H.InputName = 'y';     H.OutputName = 'yh';      H.Name = 'H';

% Get system IO sizes
[nOutputF, nInputF] = iosize(F);
[nOutputC, ~] = iosize(C);
[nOutputG, ~] = iosize(G);
[nOutputH, ~] = iosize(H);

% Create the summing junctions
eSum = sumblk('eSwitchInputName = -ym + rf',nOutputF); % Sum at e
uSum = sumblk('uSwitchInputName = uc + du',nOutputC); % Sum at u
ySum = sumblk('ySwitchInputName = yg + dy',nOutputG); % Sum at y
ymSum = sumblk('ymSwitchInputName = yh + n',nOutputH); % Sum at ym

% Create the Analysis Points
rSwitch = AnalysisPoint('r',nInputF); % Analysis Point at r
rSwitch.InputName = 'r';     rSwitch.OutputName = 'rSwitchOutputName';
eSwitch = AnalysisPoint('e',nOutputF); % Analysis Point at e
eSwitch.InputName = 'eSwitchInputName';     eSwitch.OutputName = 'e';
uSwitch = AnalysisPoint('u',nOutputC); % Analysis Point at u
uSwitch.InputName = 'uSwitchInputName';     uSwitch.OutputName = 'u';
ySwitch = AnalysisPoint('y',nOutputF); % Analysis Point at y
ySwitch.InputName = 'ySwitchInputName';     ySwitch.OutputName = 'y';
ymSwitch = AnalysisPoint('ym',nOutputH); % Analysis Point at ym
ymSwitch.InputName = 'ymSwitchInputName';     ymSwitch.OutputName = 'ym';

% Construct the closed loop system
Inputs = {'r';'du';'dy';'n'};
Outputs = {'y';'e';'u';'ym'};
CL0 = connect(C,F,G,H,eSum,uSum,ySum,ymSum,rSwitch,eSwitch,uSwitch,ySwitch,ymSwitch,Inputs,Outputs);

%% Create tuning goal to make the closed-loop step response closely match the desired response
% Inputs and outputs
Inputs = {'r'};
Outputs = {'y'};
% Tuning goal specifications
ReferenceModel = tf(1,[1 1]); % LTI model to match
InputSignal = 'impulse'; % Input shaping filter ('impulse', 'step', 'ramp', or a SISO transfer function)
% Create tuning goal for transient
TransientGoal1 = TuningGoal.Transient(Inputs,Outputs,ReferenceModel,InputSignal);
TransientGoal1.Name = 'TransientGoal1'; % Tuning goal name

%% Create option set for systune command
Options = systuneOptions();
Options.Display = 'off'; % Tuning display level ('final', 'sub', 'iter', 'off')

%% Set soft and hard goals
SoftGoals = [ TransientGoal1 ];
HardGoals = [];

%% Tune the parameters with soft and hard goals
[CL1,fSoft,gHard,Info] = systune(CL0,SoftGoals,HardGoals,Options);

%% View tuning results
% viewSpec([SoftGoals;HardGoals],CL1);
